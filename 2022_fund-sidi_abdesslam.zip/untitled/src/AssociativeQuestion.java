public class AssociativeQuestion {
}
