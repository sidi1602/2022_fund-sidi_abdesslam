public class MCQAnswer {
    Quiz quiz;
    MCQChoice mcqChoice;

    public Quiz getQuiz() {
        return quiz;
    }

    public void setQuiz(Quiz quiz) {
        this.quiz = quiz;
    }

    public MCQChoice getMcqChoice() {
        return mcqChoice;
    }

    public void setMcqChoice(MCQChoice mcqChoice) {
        this.mcqChoice = mcqChoice;
    }

    public MCQAnswer(Quiz quiz, MCQChoice mcqChoice) {
        this.quiz = quiz;
        this.mcqChoice = mcqChoice;
    }
}
