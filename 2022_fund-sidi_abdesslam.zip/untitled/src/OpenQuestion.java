public class OpenQuestion {
}
