public class Answer {
     String text;

     public Answer(String text) {
          this.text = text;
     }
}
