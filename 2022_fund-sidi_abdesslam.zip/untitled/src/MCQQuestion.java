public class MCQQuestion {

}
