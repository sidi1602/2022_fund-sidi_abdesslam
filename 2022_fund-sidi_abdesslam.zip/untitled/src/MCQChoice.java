public class MCQChoice {
    MCQQuestion mcqQuestion;

    public MCQQuestion getMcqQuestion() {
        return mcqQuestion;
    }

    public void setMcqQuestion(MCQQuestion mcqQuestion) {
        this.mcqQuestion = mcqQuestion;
    }

    public MCQChoice(MCQQuestion mcqQuestion) {
        this.mcqQuestion = mcqQuestion;
    }
}
