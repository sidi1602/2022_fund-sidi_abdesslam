public class Question {
    String Question;
    String topics;
    int difficulty;

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }

    public String getTopics() {
        return topics;
    }

    public void setTopics(String topics) {
        this.topics = topics;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public Question(String question, String topics, int difficulty) {
        Question = question;
        this.topics = topics;
        this.difficulty = difficulty;
    }
}
