
import java.io.InputStream;
import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        //create student
        System.out.println("enter student name ");
        Scanner inp = new Scanner(System.in);
        String name= inp.nextLine();
        System.out.println("enter student id ");
        int id= inp.nextInt();
        Student student = new Student(name,id);











    }
}
